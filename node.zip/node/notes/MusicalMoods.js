module.exports.musicalMoods = ({
    major: "Major",
    minor: "Minor",
});
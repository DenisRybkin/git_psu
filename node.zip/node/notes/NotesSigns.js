module.exports.notesSigns = ([
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "H",
]);